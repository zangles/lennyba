INSERT INTO PREFIX_megamenus_module_lang VALUES("1","id_lang","Menu");
