INSERT INTO PREFIX_flexgroupbanners_group_lang VALUES("1","id_lang","Group 1");
INSERT INTO PREFIX_flexgroupbanners_group_lang VALUES("2","id_lang","Group 2");

