INSERT INTO PREFIX_pagelink_item VALUES("6","2","0","PAG-my-account","0","","1","1","header-links-icon icon-account");
INSERT INTO PREFIX_pagelink_item VALUES("7","2","0","PAG-cart","0","","1","2","header-links-icon icon-checkout");
INSERT INTO PREFIX_pagelink_item VALUES("8","2","0","PAG-module-blockwishlist-mywishlist","0","","1","3","header-links-icon icon-wishlist");
INSERT INTO PREFIX_pagelink_item VALUES("9","2","0","CUSTOMLINK-0","0","","0","4","header-links-icon icon-fav");
INSERT INTO PREFIX_pagelink_item VALUES("13","2","0","PAG-authentication","0","","1","5","header-links-icon icon-login");

