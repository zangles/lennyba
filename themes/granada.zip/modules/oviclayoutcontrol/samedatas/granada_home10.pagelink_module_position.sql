INSERT INTO PREFIX_pagelink_module_position VALUES("3","100","displayNav");

