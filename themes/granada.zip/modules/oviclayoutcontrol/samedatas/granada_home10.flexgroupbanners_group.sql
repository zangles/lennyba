INSERT INTO PREFIX_flexgroupbanners_group VALUES("1","1","1","","","0","1","1");
INSERT INTO PREFIX_flexgroupbanners_group VALUES("3","2","2","col-special col-3-1","","0","1","1");
INSERT INTO PREFIX_flexgroupbanners_group VALUES("4","2","2","col-special col-3-2","","0","1","2");
INSERT INTO PREFIX_flexgroupbanners_group VALUES("5","3","3","row banner-row","","0","1","1");
INSERT INTO PREFIX_flexgroupbanners_group VALUES("6","3","3","col-special col-1 last","","0","1","2");
INSERT INTO PREFIX_flexgroupbanners_group VALUES("8","4","5","","","0","1","1");
INSERT INTO PREFIX_flexgroupbanners_group VALUES("9","5","6","","","0","1","1");
INSERT INTO PREFIX_flexgroupbanners_group VALUES("10","6","7","","","0","1","1");

