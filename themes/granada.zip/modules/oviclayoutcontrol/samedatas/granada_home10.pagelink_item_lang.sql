INSERT INTO PREFIX_pagelink_item_lang VALUES("10","id_lang","Login","");
INSERT INTO PREFIX_pagelink_item_lang VALUES("11","id_lang","Currency","");
INSERT INTO PREFIX_pagelink_item_lang VALUES("12","id_lang","Language","");
INSERT INTO PREFIX_pagelink_item_lang VALUES("14","id_lang","My Account","");
INSERT INTO PREFIX_pagelink_item_lang VALUES("15","id_lang","My Wishlist","");
INSERT INTO PREFIX_pagelink_item_lang VALUES("16","id_lang","Checkout","");

