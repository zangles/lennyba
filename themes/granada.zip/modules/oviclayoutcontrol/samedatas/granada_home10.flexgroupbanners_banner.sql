INSERT INTO PREFIX_flexgroupbanners_banner VALUES("1","1","1","1","col-special col-3-2","1","1");
INSERT INTO PREFIX_flexgroupbanners_banner VALUES("3","1","1","1","col-special col-3-1","1","2");
INSERT INTO PREFIX_flexgroupbanners_banner VALUES("4","2","2","4","","1","1");
INSERT INTO PREFIX_flexgroupbanners_banner VALUES("5","2","2","3","banner-row-link","1","1");
INSERT INTO PREFIX_flexgroupbanners_banner VALUES("6","2","2","3","banner-row-link","1","2");
INSERT INTO PREFIX_flexgroupbanners_banner VALUES("8","3","3","5","col-special col-1-2","1","1");
INSERT INTO PREFIX_flexgroupbanners_banner VALUES("9","3","3","5","col-special col-1-2","1","2");
INSERT INTO PREFIX_flexgroupbanners_banner VALUES("10","3","3","6","","1","1");
INSERT INTO PREFIX_flexgroupbanners_banner VALUES("11","4","5","8","col-special col-1","1","1");
INSERT INTO PREFIX_flexgroupbanners_banner VALUES("12","4","5","8","col-special col-1 last","1","2");
INSERT INTO PREFIX_flexgroupbanners_banner VALUES("13","5","6","9","col-special col-3-1","1","1");
INSERT INTO PREFIX_flexgroupbanners_banner VALUES("14","5","6","9","col-special col-3-2","1","2");
INSERT INTO PREFIX_flexgroupbanners_banner VALUES("15","6","7","10","col-special col-3-2 col-full-sm","1","1");
INSERT INTO PREFIX_flexgroupbanners_banner VALUES("16","6","7","10","col-special col-3-1 col-full-sm hidden-sm","1","2");

