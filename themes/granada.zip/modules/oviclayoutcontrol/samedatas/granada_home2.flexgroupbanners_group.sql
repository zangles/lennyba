INSERT INTO PREFIX_flexgroupbanners_group VALUES("1","1","1","banner hover-zoom full-inner","","6","1","1");
INSERT INTO PREFIX_flexgroupbanners_group VALUES("2","1","1","banner hover-zoom","","6","1","2");

