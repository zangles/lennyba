INSERT INTO PREFIX_flexgroupbanners_row_lang VALUES("1","id_lang","Wrap group banner home1");
INSERT INTO PREFIX_flexgroupbanners_row_lang VALUES("2","id_lang","Row");
INSERT INTO PREFIX_flexgroupbanners_row_lang VALUES("3","id_lang","Row");
INSERT INTO PREFIX_flexgroupbanners_row_lang VALUES("5","id_lang","Row");
INSERT INTO PREFIX_flexgroupbanners_row_lang VALUES("6","id_lang","Row");
INSERT INTO PREFIX_flexgroupbanners_row_lang VALUES("7","id_lang","Row");

