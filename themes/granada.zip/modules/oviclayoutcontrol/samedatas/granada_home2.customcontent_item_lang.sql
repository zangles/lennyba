INSERT INTO PREFIX_customcontent_item_lang VALUES("1","id_lang","FREE DELIVERY","","<p>Cras pellentesque, nisi ac tempus pellentesque, orci sem commodo urna, amet egestas ipsum orci sit amet.</p>","","");
INSERT INTO PREFIX_customcontent_item_lang VALUES("2","id_lang","24/H CUSTOMER SERVICE","","<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas praesent tempor.</p>","","");
INSERT INTO PREFIX_customcontent_item_lang VALUES("3","id_lang","PAYMENT SECURED","","<p>Aenean porta adipiscing tortor, nec consequat nisi mollis sed. Aliquam orn are magna sed leo varius, quis.</p>","","");

