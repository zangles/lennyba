INSERT INTO PREFIX_flexgroupbanners_module_lang VALUES("1","id_lang","Home group home1");
INSERT INTO PREFIX_flexgroupbanners_module_lang VALUES("2","id_lang","Banner home top content");
INSERT INTO PREFIX_flexgroupbanners_module_lang VALUES("3","id_lang","Banner displayGroupBanner1");
INSERT INTO PREFIX_flexgroupbanners_module_lang VALUES("4","id_lang","Banner displayGroupBanner2");
INSERT INTO PREFIX_flexgroupbanners_module_lang VALUES("5","id_lang","Banner displayhome");
INSERT INTO PREFIX_flexgroupbanners_module_lang VALUES("6","id_lang","Banner displaygroupbanner3");

