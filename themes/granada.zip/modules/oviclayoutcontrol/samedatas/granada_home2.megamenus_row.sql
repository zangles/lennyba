INSERT INTO PREFIX_megamenus_row VALUES("1","1","2","12","1","1","","0","");
INSERT INTO PREFIX_megamenus_row VALUES("2","2","14","12","1","1","","0","http://sw-themes.com/prestashop/granada/option2/modules/megamenus/images/535fd76dbe327878151e53aca69e49ae_Tulips.jpg");
INSERT INTO PREFIX_megamenus_row VALUES("4","3","33","12","1","1","","0","");
