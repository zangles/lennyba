INSERT INTO PREFIX_bannerslider_item VALUES("1","1","1","3","","");
INSERT INTO PREFIX_bannerslider_item VALUES("2","1","1","4","","");
INSERT INTO PREFIX_bannerslider_item VALUES("3","1","1","5","","");
INSERT INTO PREFIX_bannerslider_item VALUES("4","2","1","1","","");
INSERT INTO PREFIX_bannerslider_item VALUES("5","2","1","2","","");

