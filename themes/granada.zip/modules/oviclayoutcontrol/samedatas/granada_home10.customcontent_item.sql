INSERT INTO PREFIX_customcontent_item VALUES("1","1","CAT-3","0","","1","1","","2fe67ea2dc20a60346f24d160f92997f_home_9_1.jpg","0");
INSERT INTO PREFIX_customcontent_item VALUES("2","1","CAT-12","0","","1","2","","a0c180c562e438b8485ac0d4bd48ab2d_home_9_2.jpg","0");
INSERT INTO PREFIX_customcontent_item VALUES("3","1","PAG-new-products","0","","1","3","","7460d2e0b256120b07d16611344324ec_home_9_3.jpg","0");
INSERT INTO PREFIX_customcontent_item VALUES("4","1","PAG-best-sales","0","","1","4","","02cd1c7dbddf47dc68aa979ecb167ca4_home_9_4.jpg","0");
INSERT INTO PREFIX_customcontent_item VALUES("5","1","PAG-supplier","0","","1","5","","eb846f2d61978bc95f6c46aab403a240_home_9_1.jpg","0");

