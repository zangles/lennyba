INSERT INTO PREFIX_megaboxs_row VALUES("2","2","0","12","1","1","","0");
