INSERT INTO PREFIX_flexgroupbanners_module_lang VALUES("1","id_lang","Home group home1");

