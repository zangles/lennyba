INSERT INTO PREFIX_flexbanner_banner_position VALUES("2","7","displayRightColumn");

