INSERT INTO PREFIX_pagelink_module_position VALUES("2","100","displayNav");

