INSERT INTO PREFIX_flexbanner_banner VALUES("2","1","displayLeftColumn","banner hover-zoom","0","default","1","2","");

