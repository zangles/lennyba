INSERT INTO PREFIX_bannerslider_item_lang VALUES("1","id_lang","http://sw-themes.com/prestashop/granada/option10/modules/bannerslider/images/1441096942.png","slider","");
INSERT INTO PREFIX_bannerslider_item_lang VALUES("2","id_lang","http://sw-themes.com/prestashop/granada/option10/modules/bannerslider/images/1440944491.png","slider","");
INSERT INTO PREFIX_bannerslider_item_lang VALUES("3","id_lang","http://sw-themes.com/prestashop/granada/option10/modules/bannerslider/images/1440944521.png","slider","");
INSERT INTO PREFIX_bannerslider_item_lang VALUES("4","id_lang","http://sw-themes.com/prestashop/granada/option10/modules/bannerslider/images/1442978896.jpg","slider","");
INSERT INTO PREFIX_bannerslider_item_lang VALUES("5","id_lang","http://sw-themes.com/prestashop/granada/option10/modules/bannerslider/images/1442978875.jpg","slider","");

