INSERT INTO PREFIX_pagelink_module VALUES("2","1","displayNav","1","default","2","1","left-side","0","");

