INSERT INTO PREFIX_flexgroupbanners_row VALUES("1","1","0","0","row banner-row","1","1");
INSERT INTO PREFIX_flexgroupbanners_row VALUES("2","2","0","0","row banner-row","1","1");
INSERT INTO PREFIX_flexgroupbanners_row VALUES("3","3","0","0","","1","1");
INSERT INTO PREFIX_flexgroupbanners_row VALUES("5","4","0","0","","1","1");
INSERT INTO PREFIX_flexgroupbanners_row VALUES("6","5","0","0","row banner-row","1","1");
INSERT INTO PREFIX_flexgroupbanners_row VALUES("7","6","0","0","row banner-row","1","1");

