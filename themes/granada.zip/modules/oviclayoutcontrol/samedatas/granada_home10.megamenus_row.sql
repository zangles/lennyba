INSERT INTO PREFIX_megamenus_row VALUES("1","1","2","12","1","1","","0","");
INSERT INTO PREFIX_megamenus_row VALUES("7","1","24","12","2","1","","0","");
