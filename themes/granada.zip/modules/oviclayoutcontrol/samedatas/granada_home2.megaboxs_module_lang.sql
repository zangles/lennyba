INSERT INTO PREFIX_megaboxs_module_lang VALUES("1","id_lang","home bottom");
INSERT INTO PREFIX_megaboxs_module_lang VALUES("2","id_lang","bottom");
INSERT INTO PREFIX_megaboxs_module_lang VALUES("3","id_lang","footer");
