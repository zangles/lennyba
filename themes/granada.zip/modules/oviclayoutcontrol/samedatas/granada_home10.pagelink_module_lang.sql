INSERT INTO PREFIX_pagelink_module_lang VALUES("3","id_lang","Page link");

