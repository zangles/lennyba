INSERT INTO PREFIX_flexgroupbanners_module VALUES("1","1","displayHomeTopColumn","0","default","1","1","fluid-container .banner-row-container","");
INSERT INTO PREFIX_flexgroupbanners_module VALUES("2","1","displayHomeTopContent","0","default","2","1","fluid-container .banner-row-container","");
INSERT INTO PREFIX_flexgroupbanners_module VALUES("3","1","displayGroupBanner1","0","default","3","1","","");
INSERT INTO PREFIX_flexgroupbanners_module VALUES("4","1","displayGroupBanner2","0","default","4","1","","");
INSERT INTO PREFIX_flexgroupbanners_module VALUES("5","1","displayHome","0","default","5","1","fluid-container .banner-row-container","");
INSERT INTO PREFIX_flexgroupbanners_module VALUES("6","1","displayGroupBanner3","0","default","6","1","fluid-container .banner-row-container","");

