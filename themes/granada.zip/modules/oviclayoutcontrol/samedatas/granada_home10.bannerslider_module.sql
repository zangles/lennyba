INSERT INTO PREFIX_bannerslider_module VALUES("1","1","0","displayBannerSlider1","default","","1","0","1","");
INSERT INTO PREFIX_bannerslider_module VALUES("2","1","0","displayBannerSlider2","lookbook","","1","1","2","");

