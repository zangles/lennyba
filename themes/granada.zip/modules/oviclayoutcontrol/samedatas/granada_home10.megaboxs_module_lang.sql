INSERT INTO PREFIX_megaboxs_module_lang VALUES("2","id_lang","bottom");
