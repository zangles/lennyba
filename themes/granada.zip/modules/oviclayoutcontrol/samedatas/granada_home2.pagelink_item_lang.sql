INSERT INTO PREFIX_pagelink_item_lang VALUES("6","id_lang","My Account","#");
INSERT INTO PREFIX_pagelink_item_lang VALUES("7","id_lang","Checkout","");
INSERT INTO PREFIX_pagelink_item_lang VALUES("8","id_lang","My Wishlist","");
INSERT INTO PREFIX_pagelink_item_lang VALUES("9","id_lang","My favorites","#");
INSERT INTO PREFIX_pagelink_item_lang VALUES("13","id_lang","Login","");

