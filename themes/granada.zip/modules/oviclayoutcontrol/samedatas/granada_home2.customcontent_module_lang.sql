INSERT INTO PREFIX_customcontent_module_lang VALUES("1","id_lang","SERVICE","<div class=\"lg-margin3x xs-margin2x\"></div><div class=\"sm-margin visible-xs\"></div>","");

