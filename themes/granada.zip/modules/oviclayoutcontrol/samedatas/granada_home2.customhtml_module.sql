INSERT INTO PREFIX_customhtml_module VALUES("1","1","displayLeftColumn","0","default","1","1","","");
INSERT INTO PREFIX_customhtml_module VALUES("2","1","CustomHtml","0","default","1","1","","");
INSERT INTO PREFIX_customhtml_module VALUES("3","1","displayFooter","0","default","1","1","","");
INSERT INTO PREFIX_customhtml_module VALUES("4","1","displayRightColumn","0","default","1","1","","");
INSERT INTO PREFIX_customhtml_module VALUES("7","1","displaySmartBlogLeft","0","default","1","1","","");
INSERT INTO PREFIX_customhtml_module VALUES("8","1","displayBottomContact","0","default","1","1","","");
INSERT INTO PREFIX_customhtml_module VALUES("9","1","displayLeftColumn","0","default","2","1","","");
INSERT INTO PREFIX_customhtml_module VALUES("10","1","displaySmartBlogRight","0","default","2","1","","");

