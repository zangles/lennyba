INSERT INTO PREFIX_megaboxs_module VALUES("2","1","blanktheme","","displayBottomColumn","default","1","10","1","1","","");
