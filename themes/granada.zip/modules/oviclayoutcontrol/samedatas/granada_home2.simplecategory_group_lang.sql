INSERT INTO PREFIX_simplecategory_group_lang VALUES("1","id_lang","New Arrivals","","");
INSERT INTO PREFIX_simplecategory_group_lang VALUES("2","id_lang","Bestsellers","","");
INSERT INTO PREFIX_simplecategory_group_lang VALUES("3","id_lang","Featured","","");
