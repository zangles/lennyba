INSERT INTO PREFIX_pagelink_module_lang VALUES("2","id_lang","Nav left");

