INSERT INTO PREFIX_flexgroupbanners_banner VALUES("1","1","1","1","banner banner-sm text-right","1","1");
INSERT INTO PREFIX_flexgroupbanners_banner VALUES("2","1","1","2","banner banner-sm last text-right","1","1");

