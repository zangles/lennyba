INSERT INTO PREFIX_customcontent_item VALUES("1","1","CUSTOMLINK-0","0","","1","1","feature-icon icon-delivery","","4");
INSERT INTO PREFIX_customcontent_item VALUES("2","1","CUSTOMLINK-0","0","","1","2","feature-icon icon-service","","4");
INSERT INTO PREFIX_customcontent_item VALUES("3","1","CUSTOMLINK-0","0","","1","3","feature-icon icon-secured","","4");

