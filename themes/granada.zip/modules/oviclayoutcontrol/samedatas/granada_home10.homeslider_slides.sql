INSERT INTO PREFIX_homeslider_slides VALUES("5","0","1");
INSERT INTO PREFIX_homeslider_slides VALUES("6","0","1");
INSERT INTO PREFIX_homeslider_slides VALUES("7","0","1");

