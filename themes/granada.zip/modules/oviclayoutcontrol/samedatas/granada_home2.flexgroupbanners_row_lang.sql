INSERT INTO PREFIX_flexgroupbanners_row_lang VALUES("1","id_lang","Wrap group banner home1");

