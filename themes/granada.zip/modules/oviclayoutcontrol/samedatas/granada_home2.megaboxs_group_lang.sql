INSERT INTO PREFIX_megaboxs_group_lang VALUES("1","id_lang","Top Rated","","");
INSERT INTO PREFIX_megaboxs_group_lang VALUES("2","id_lang","From Twitter","","<ul class=\"twitter-top-widget\"><li>�</li></ul>");
INSERT INTO PREFIX_megaboxs_group_lang VALUES("3","id_lang","Quick Contact","","<div id=\"footer-top-small-map\">�</div>\n<form id=\"quick-contact\" action=\"#\">\n<div class=\"form-group\"><input class=\"form-control input-lg\" type=\"text\" /></div>\n<div class=\"form-group\"><input class=\"form-control input-lg\" type=\"text\" /></div>\n<div class=\"form-group clear-margin\"> </div>\n<div class=\"xs-margin half\"> </div>\n<div class=\"form-group\"><input class=\"btn btn-custom-9 min-width-md\" type=\"submit\" value=\"Send Message\" /></div>\n<div class=\"xs-margin visible-md visible-lg\"> </div>\n</form>");
INSERT INTO PREFIX_megaboxs_group_lang VALUES("4","id_lang","my account","","");
INSERT INTO PREFIX_megaboxs_group_lang VALUES("5","id_lang","Powered by","","<p class=\"copyright-text\">� 2014 Powered by WooCommerce�. All Rights Reserved.</p>");
INSERT INTO PREFIX_megaboxs_group_lang VALUES("6","id_lang","","","");
INSERT INTO PREFIX_megaboxs_group_lang VALUES("7","id_lang","customer service","","");
INSERT INTO PREFIX_megaboxs_group_lang VALUES("8","id_lang","From Twitter","","");
