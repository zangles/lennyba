INSERT INTO PREFIX_pagelink_item VALUES("10","3","0","PAG-authentication","0","","1","4","");
INSERT INTO PREFIX_pagelink_item VALUES("11","3","0","CURRENCY-BOX","0","","1","5","");
INSERT INTO PREFIX_pagelink_item VALUES("12","3","0","LANGUAGE-BOX","0","","1","6","");
INSERT INTO PREFIX_pagelink_item VALUES("14","3","0","PAG-my-account","0","","1","1","");
INSERT INTO PREFIX_pagelink_item VALUES("15","3","0","PAG-module-blockwishlist-mywishlist","0","","1","2","");
INSERT INTO PREFIX_pagelink_item VALUES("16","3","0","PAG-cart","0","","1","3","");

