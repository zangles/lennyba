INSERT INTO PREFIX_customcontent_module_lang VALUES("1","id_lang","Home content","","");

