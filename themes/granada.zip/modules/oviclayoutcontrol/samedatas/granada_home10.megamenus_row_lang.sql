INSERT INTO PREFIX_megamenus_row_lang VALUES("1","id_lang","Row");
INSERT INTO PREFIX_megamenus_row_lang VALUES("7","id_lang","Copy Row");
