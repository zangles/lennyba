INSERT INTO PREFIX_megamenus_module_lang VALUES("1","id_lang","Menu left");
INSERT INTO PREFIX_megamenus_module_lang VALUES("2","id_lang","Categories");
INSERT INTO PREFIX_megamenus_module_lang VALUES("3","id_lang","Menu right");
