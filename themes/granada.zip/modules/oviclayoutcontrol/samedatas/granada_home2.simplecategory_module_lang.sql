INSERT INTO PREFIX_simplecategory_module_lang VALUES("6","id_lang","Popular","","");
INSERT INTO PREFIX_simplecategory_module_lang VALUES("7","id_lang","BEST SELLERS","","");
INSERT INTO PREFIX_simplecategory_module_lang VALUES("8","id_lang","Best Sellers","","");
INSERT INTO PREFIX_simplecategory_module_lang VALUES("9","id_lang","Home tab","","");
INSERT INTO PREFIX_simplecategory_module_lang VALUES("10","id_lang","New Arrivals","","");
INSERT INTO PREFIX_simplecategory_module_lang VALUES("11","id_lang","Best Sellers","","");
INSERT INTO PREFIX_simplecategory_module_lang VALUES("12","id_lang","Best Sellers","","");
