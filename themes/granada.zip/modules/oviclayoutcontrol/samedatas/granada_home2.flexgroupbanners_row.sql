INSERT INTO PREFIX_flexgroupbanners_row VALUES("1","1","0","0","","1","1");

