INSERT INTO PREFIX_flexgroupbanners_group_lang VALUES("1","id_lang","Group 1");
INSERT INTO PREFIX_flexgroupbanners_group_lang VALUES("3","id_lang","Group 1");
INSERT INTO PREFIX_flexgroupbanners_group_lang VALUES("4","id_lang","Group 2");
INSERT INTO PREFIX_flexgroupbanners_group_lang VALUES("5","id_lang","Group");
INSERT INTO PREFIX_flexgroupbanners_group_lang VALUES("6","id_lang","Group 2");
INSERT INTO PREFIX_flexgroupbanners_group_lang VALUES("8","id_lang","Group");
INSERT INTO PREFIX_flexgroupbanners_group_lang VALUES("9","id_lang","Group");
INSERT INTO PREFIX_flexgroupbanners_group_lang VALUES("10","id_lang","Group");

