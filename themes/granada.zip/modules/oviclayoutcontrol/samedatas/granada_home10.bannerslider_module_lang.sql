INSERT INTO PREFIX_bannerslider_module_lang VALUES("1","id_lang","Banner slider 1","","our spring / summerPrevious Slide Next Slidenew arrivalsDonec gravida elit sed rhoncus eleifend. Nam viverra lacus non lobortis malesuada fusce.TAKE LOOK","","");
INSERT INTO PREFIX_bannerslider_module_lang VALUES("2","id_lang","Banner slider 2","","autumn / winter 2014Previous Slide Next SlidelookbookAenean eu vulputate tortor, quis iaculis sapien. Phasellus pharetra faucibus hendrerit nam ipsum.TAKE LOOK","","");

