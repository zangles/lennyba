INSERT INTO PREFIX_megaboxs_row_lang VALUES("1","id_lang","Row");
INSERT INTO PREFIX_megaboxs_row_lang VALUES("2","id_lang","Row");
INSERT INTO PREFIX_megaboxs_row_lang VALUES("3","id_lang","");
