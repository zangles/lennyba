INSERT INTO PREFIX_megaboxs_module VALUES("1","1","blanktheme","","displayHomeBottomColumn","default","1","10","1","1","","");
INSERT INTO PREFIX_megaboxs_module VALUES("2","1","blanktheme","","displayBottomColumn","default","1","10","1","1","","");
INSERT INTO PREFIX_megaboxs_module VALUES("3","1","blanktheme","","displayFooter","default","1","10","1","1","","");
