<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{flexiblecustom}prestashop>flexiblecustom_f7c34fc4a48bc683445c1e7bbc245508'] = 'sdfdsfsd';

return $_MODULE;
