<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksearch}prestashop>blocksearch-top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Buscar';
$_MODULE['<{blocksearch}prestashop>blocksearch_31a0c03d7fbd1dc61d3b8e02760e703b'] = 'Bloque de búsqueda rápida';
$_MODULE['<{blocksearch}prestashop>blocksearch_99e20473c0bf3c22d7420eff03ce66c3'] = 'Añada u bloque con un campo de búsqueda rápida';
$_MODULE['<{blocksearch}prestashop>blocksearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Buscar';
$_MODULE['<{blocksearch}prestashop>blocksearch_52d578d063d6101bbdae388ece037e60'] = 'Introduzca el nombre del producto';
$_MODULE['<{blocksearch}prestashop>blocksearch_34d1f91fb2e514b8576fab1a75a89a6b'] = 'buscar';
