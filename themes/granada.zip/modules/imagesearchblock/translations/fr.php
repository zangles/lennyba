<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{imagesearchblock}prestashop>imagesearchblock-instantsearch_d3da97e2d9aee5c8fbe03156ad051c99'] = 'More';
$_MODULE['<{imagesearchblock}prestashop>imagesearchblock-top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Search';
$_MODULE['<{imagesearchblock}prestashop>imagesearchblock_afa78160ac8c1fc31d5b05a1382a5474'] = 'image Theme - Search Block with Extended Features';
$_MODULE['<{imagesearchblock}prestashop>imagesearchblock_9f5afc499e055dc78924487d95c09af9'] = 'Adds a quick search block.';
$_MODULE['<{imagesearchblock}prestashop>imagesearchblock_13348442cc6a27032d2b4aa28b75a5d3'] = 'Search';
$_MODULE['<{imagesearchblock}prestashop>imagesearchblock_52d578d063d6101bbdae388ece037e60'] = 'Enter a product name';
$_MODULE['<{imagesearchblock}prestashop>imagesearchblock_34d1f91fb2e514b8576fab1a75a89a6b'] = 'go';
