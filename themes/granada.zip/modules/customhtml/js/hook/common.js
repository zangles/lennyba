/*
$(document).ready(function(){
	$('.sticky-language > a').click(function(event) {
        event.preventDefault();
    });
    $('.sticky-language').hover(function() {
        $(this).addClass('open');
    }, function() {
        $(this).removeClass('open');
    });
    $('.sticky-currency > a').click(function(event) {
        event.preventDefault();
    });
    $('.sticky-currency').hover(function() {
        $(this).addClass('open');
    }, function() {
        $(this).removeClass('open');
    });
});
*/
