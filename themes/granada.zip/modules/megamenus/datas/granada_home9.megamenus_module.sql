INSERT INTO PREFIX_megamenus_module VALUES("1","1","blanktheme","","displayTopColumn","horizontal_top","1","10","1","1","","");
INSERT INTO PREFIX_megamenus_module VALUES("2","1","blanktheme","","displayVerticalMenu","vertical_left","1","10","1","1","","");
