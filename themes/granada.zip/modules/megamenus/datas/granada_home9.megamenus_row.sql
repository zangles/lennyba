INSERT INTO PREFIX_megamenus_row VALUES("1","1","2","12","1","1","","0","");
INSERT INTO PREFIX_megamenus_row VALUES("2","2","14","12","1","1","","0","00050ac7b206e48794fef39023fc96d0_sidemenubg.png");
INSERT INTO PREFIX_megamenus_row VALUES("4","2","21","12","2","1","","0","8dc8c314948e14ce2f741a73d811274d_sidemenubg.png");
INSERT INTO PREFIX_megamenus_row VALUES("5","2","22","12","3","1","","0","4eab982ec4556ea0f012d89ab26ba93f_sidemenubg.png");
INSERT INTO PREFIX_megamenus_row VALUES("7","1","24","12","2","1","","0","");
